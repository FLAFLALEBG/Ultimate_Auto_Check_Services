#!/usr/bin/env python

import uacs
import os
import sys

sys.stdout = open(os.devnull, 'w')
uacs.restore(True)

# --------------* Variables *-------------- #

option = 1
command = 2
argument = 3
have_argument = False


# --------------* Argv *-------------- #

# ---* Option *--- #
try:
    global verbose
    if str(sys.argv[1]) == "-v" or str(sys.argv[1]) == "--verbose":
        sys.stdout = sys.__stdout__
        verbose = True

    elif str(sys.argv[1]) != "-v" or str(sys.argv[1]) != "--verbose":
        option -= 1
        command -= 1
        argument -= 1
        verbose = False

except:
    uacs.run_daemon()  # Run daemon

# ---* Command *--- #
if str(sys.argv[command]) == "append":
    try:
        argv_service = sys.argv[command + 1]
        uacs.append(argv_service, verbose)
    except:
        print("commande usage: uacs append 'service_to_append'")

elif str(sys.argv[command]) == "--help" or str(sys.argv[command]) == "-h":
    sys.stdout = sys.__stdout__
    docs = open("docs/help.txt", "r")
    print(docs.read())
    docs.close()

elif str(sys.argv[command]) == "start":
    uacs.run_daemon()

elif str(sys.argv[command]) == "send_mail":
    uacs.send_mail("test", verbose)

elif str(sys.argv[command]) == "restore":
    uacs.restore(verbose)

elif str(sys.argv[command]) == "restore_service":
    uacs.restore_service(verbose)

elif str(sys.argv[command]) == "restore_email":
    uacs.restore_email(verbose)

elif str(sys.argv[command]) == "init":
    uacs.init()

elif str(sys.argv[command]) == "stop":
    pass  # running = False

print("Command invalid or invalid arguments")
