# Ultimate_Auto_Check_Services
This script allows to check services under Linux and sends mails in case of crash of one of them.

# #--------------* UNDER DEVELOPMENT  *--------------#
